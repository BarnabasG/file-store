import pygame
import sys
import random
import math
import time
from pygame.locals import *

# Initialize pygame with no audio to avoid ALSA errors
pygame.init()
pygame.mixer.quit()  # Disable the mixer module to avoid audio errors

# Game constants
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60
GAME_DURATION = 300  # 5 minutes in seconds
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
PURPLE = (128, 0, 128)

# Game state
class GameState:
    def __init__(self):
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("SirLootsalot")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 24)
        self.running = True
        self.game_over = False
        self.current_level = 1
        self.start_time = time.time()
        self.remaining_time = GAME_DURATION
        
        # Game objects
        self.player = Player()
        self.nutrinium_deposits = []
        self.pirates = []
        self.projectiles = []
        self.explosions = []
        
        # Economy
        self.nutrinium_value = 10.0  # Base value
        self.value_change_timer = 0
        self.value_direction = 1  # 1 for up, -1 for down
        self.value_change_frequency = 2  # seconds
        
        # Level setup
        self.setup_level(self.current_level)
    
    def setup_level(self, level):
        # Clear existing objects
        self.nutrinium_deposits.clear()
        self.pirates.clear()
        self.projectiles.clear()
        
        # Level difficulty scaling
        num_deposits = 5 + level
        num_pirates = max(1, level - 1)
        
        # Create nutrinium deposits
        for _ in range(num_deposits):
            x = random.randint(50, SCREEN_WIDTH - 50)
            y = random.randint(50, SCREEN_HEIGHT - 50)
            size = random.randint(1, 3)
            self.nutrinium_deposits.append(NutriniumDeposit(x, y, size))
        
        # Create pirates
        for _ in range(num_pirates):
            x = random.randint(50, SCREEN_WIDTH - 50)
            y = random.randint(50, SCREEN_HEIGHT - 50)
            speed = 1 + (level * 0.2)
            health = 2 + level // 2
            self.pirates.append(Pirate(x, y, speed, health))
        
        # Position player at center of screen
        self.player.x = SCREEN_WIDTH // 2
        self.player.y = SCREEN_HEIGHT // 2
    
    def update_nutrinium_value(self):
        self.value_change_timer += 1/FPS
        
        if self.value_change_timer >= self.value_change_frequency:
            # Random walk with upward trend
            change = random.uniform(-1.0, 1.5)  # Slight upward bias
            self.nutrinium_value = max(5.0, self.nutrinium_value + change)
            
            # Occasional larger market movements
            if random.random() < 0.05:  # 5% chance
                self.nutrinium_value *= random.uniform(0.8, 1.3)
            
            self.value_change_timer = 0
    
    def update(self):
        # Update game timer
        current_time = time.time()
        elapsed_time = current_time - self.start_time
        self.remaining_time = max(0, GAME_DURATION - elapsed_time)
        
        if self.remaining_time <= 0:
            self.game_over = True
        
        # Update nutrinium value
        self.update_nutrinium_value()
        
        # Update player
        self.player.update()
        
        # Update pirates
        for pirate in self.pirates[:]:
            pirate.update(self.player)
            
            # Check for collision with player
            if self.player.collides_with(pirate):
                self.player.take_damage()
                self.explosions.append(Explosion(self.player.x, self.player.y))
                
                if self.player.health <= 0:
                    self.player.die()
                    if self.player.credits < self.player.respawn_cost:
                        self.game_over = True
                    else:
                        self.player.credits -= self.player.respawn_cost
                        self.player.respawn_cost *= 2
                        self.player.health = self.player.max_health
                        self.player.nutrinium = 0
        
        # Update projectiles
        for projectile in self.projectiles[:]:
            projectile.update()
            
            # Remove if out of bounds
            if (projectile.x < 0 or projectile.x > SCREEN_WIDTH or 
                projectile.y < 0 or projectile.y > SCREEN_HEIGHT):
                self.projectiles.remove(projectile)
                continue
            
            # Check for collision with pirates
            for pirate in self.pirates[:]:
                if projectile.collides_with(pirate):
                    pirate.take_damage()
                    self.explosions.append(Explosion(projectile.x, projectile.y))
                    
                    if pirate.health <= 0:
                        # Transfer pirate's nutrinium to player
                        self.player.nutrinium += pirate.nutrinium
                        self.explosions.append(Explosion(pirate.x, pirate.y, large=True))
                        self.pirates.remove(pirate)
                    
                    if projectile in self.projectiles:
                        self.projectiles.remove(projectile)
                    break
        
        # Update explosions
        for explosion in self.explosions[:]:
            explosion.update()
            if explosion.frame >= explosion.max_frames:
                self.explosions.remove(explosion)
        
        # Check for mining nutrinium
        for deposit in self.nutrinium_deposits[:]:
            if self.player.collides_with(deposit):
                mining_rate = 0.1 * self.player.mining_level
                deposit.amount -= mining_rate
                self.player.nutrinium += mining_rate
                
                if deposit.amount <= 0:
                    self.nutrinium_deposits.remove(deposit)
        
        # Check if level is complete
        if len(self.nutrinium_deposits) == 0 and len(self.pirates) == 0:
            self.current_level += 1
            if self.current_level <= 10:
                self.setup_level(self.current_level)
            else:
                # Loop back to level 1 with increased difficulty
                self.current_level = 1
                self.setup_level(self.current_level)
    
    def render(self):
        # Fill background
        self.screen.fill(BLACK)
        
        # Draw stars (background)
        for _ in range(100):
            x = random.randint(0, SCREEN_WIDTH)
            y = random.randint(0, SCREEN_HEIGHT)
            size = random.randint(1, 2)
            pygame.draw.circle(self.screen, WHITE, (x, y), size)
        
        # Draw nutrinium deposits
        for deposit in self.nutrinium_deposits:
            deposit.draw(self.screen)
        
        # Draw pirates
        for pirate in self.pirates:
            pirate.draw(self.screen)
        
        # Draw projectiles
        for projectile in self.projectiles:
            projectile.draw(self.screen)
        
        # Draw explosions
        for explosion in self.explosions:
            explosion.draw(self.screen)
        
        # Draw player
        self.player.draw(self.screen)
        
        # Draw HUD
        self.draw_hud()
        
        # Draw game over screen
        if self.game_over:
            self.draw_game_over()
        
        # Update display
        pygame.display.flip()
    
    def draw_hud(self):
        # Draw time remaining
        minutes = int(self.remaining_time) // 60
        seconds = int(self.remaining_time) % 60
        time_text = f"Time: {minutes:02}:{seconds:02}"
        time_surface = self.font.render(time_text, True, WHITE)
        self.screen.blit(time_surface, (10, 10))
        
        # Draw credits
        credits_text = f"Credits: {int(self.player.credits)}"
        credits_surface = self.font.render(credits_text, True, YELLOW)
        self.screen.blit(credits_surface, (10, 50))
        
        # Draw nutrinium
        nutrinium_text = f"Nutrinium: {int(self.player.nutrinium)}"
        nutrinium_surface = self.font.render(nutrinium_text, True, GREEN)
        self.screen.blit(nutrinium_surface, (10, 90))
        
        # Draw nutrinium value
        value_text = f"Value: {self.nutrinium_value:.1f}"
        value_surface = self.font.render(value_text, True, PURPLE)
        self.screen.blit(value_surface, (10, 130))
        
        # Draw level
        level_text = f"Level: {self.current_level}/10"
        level_surface = self.font.render(level_text, True, WHITE)
        self.screen.blit(level_surface, (SCREEN_WIDTH - 150, 10))
        
        # Draw health
        health_text = f"Health: {self.player.health}/{self.player.max_health}"
        health_surface = self.font.render(health_text, True, RED)
        self.screen.blit(health_surface, (SCREEN_WIDTH - 150, 50))
        
        # Draw respawn cost
        respawn_text = f"Respawn: {self.player.respawn_cost}"
        respawn_surface = self.small_font.render(respawn_text, True, RED)
        self.screen.blit(respawn_surface, (SCREEN_WIDTH - 150, 90))
    
    def draw_game_over(self):
        # Semi-transparent overlay
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        self.screen.blit(overlay, (0, 0))
        
        # Game over text
        game_over_text = "GAME OVER"
        game_over_surface = pygame.font.Font(None, 72).render(game_over_text, True, RED)
        self.screen.blit(game_over_surface, (SCREEN_WIDTH//2 - game_over_surface.get_width()//2, SCREEN_HEIGHT//2 - 100))
        
        # Final score
        score_text = f"Final Credits: {int(self.player.credits)}"
        score_surface = self.font.render(score_text, True, YELLOW)
        self.screen.blit(score_surface, (SCREEN_WIDTH//2 - score_surface.get_width()//2, SCREEN_HEIGHT//2))
        
        # Restart instructions
        restart_text = "Press R to restart or Q to quit"
        restart_surface = self.font.render(restart_text, True, WHITE)
        self.screen.blit(restart_surface, (SCREEN_WIDTH//2 - restart_surface.get_width()//2, SCREEN_HEIGHT//2 + 100))
    
    def handle_event(self, event):
        if event.type == QUIT:
            self.running = False
        
        elif event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                self.running = False
            
            elif event.key == K_r and self.game_over:
                self.__init__()  # Reset game
            
            elif event.key == K_q and self.game_over:
                self.running = False
            
            elif event.key == K_SPACE:
                # Fire projectile
                self.projectiles.append(Projectile(self.player.x, self.player.y, self.player.angle))
            
            elif event.key == K_s:
                # Sell nutrinium
                if self.player.nutrinium > 0:
                    credits_earned = self.player.nutrinium * self.nutrinium_value
                    self.player.credits += credits_earned
                    self.player.nutrinium = 0
            
            elif event.key == K_u:
                # Upgrade mining level
                if self.player.credits >= self.player.mining_upgrade_cost:
                    self.player.credits -= self.player.mining_upgrade_cost
                    self.player.mining_level += 1
                    self.player.mining_upgrade_cost *= 2

# Player class
class Player:
    def __init__(self):
        self.x = SCREEN_WIDTH // 2
        self.y = SCREEN_HEIGHT // 2
        self.radius = 15
        self.speed = 4
        self.angle = 0
        self.health = 5
        self.max_health = 5
        self.nutrinium = 0
        self.credits = 100
        self.respawn_cost = 50
        self.mining_level = 1
        self.mining_upgrade_cost = 100
    
    def update(self):
        # Get keyboard input
        keys = pygame.key.get_pressed()
        
        # Movement
        if keys[K_w] or keys[K_UP]:
            self.y -= self.speed
        if keys[K_s] or keys[K_DOWN]:
            self.y += self.speed
        if keys[K_a] or keys[K_LEFT]:
            self.x -= self.speed
        if keys[K_d] or keys[K_RIGHT]:
            self.x += self.speed
        
        # Keep player on screen
        self.x = max(self.radius, min(SCREEN_WIDTH - self.radius, self.x))
        self.y = max(self.radius, min(SCREEN_HEIGHT - self.radius, self.y))
        
        # Update angle to face mouse
        mouse_x, mouse_y = pygame.mouse.get_pos()
        self.angle = math.atan2(mouse_y - self.y, mouse_x - self.x)
    
    def draw(self, screen):
        # Draw player body (knight in space)
        pygame.draw.circle(screen, BLUE, (int(self.x), int(self.y)), self.radius)
        
        # Draw direction indicator (sword/lance)
        end_x = self.x + math.cos(self.angle) * (self.radius + 10)
        end_y = self.y + math.sin(self.angle) * (self.radius + 10)
        pygame.draw.line(screen, WHITE, (self.x, self.y), (end_x, end_y), 3)
        
        # Draw health bar
        health_width = 30
        health_height = 5
        health_x = self.x - health_width // 2
        health_y = self.y - self.radius - 10
        
        # Background
        pygame.draw.rect(screen, RED, (health_x, health_y, health_width, health_height))
        
        # Foreground (current health)
        current_health_width = (self.health / self.max_health) * health_width
        pygame.draw.rect(screen, GREEN, (health_x, health_y, current_health_width, health_height))
    
    def take_damage(self):
        self.health -= 1
    
    def die(self):
        self.health = 0
        self.x = SCREEN_WIDTH // 2
        self.y = SCREEN_HEIGHT // 2
    
    def collides_with(self, other):
        distance = math.sqrt((self.x - other.x) ** 2 + (self.y - other.y) ** 2)
        return distance < (self.radius + other.radius)

# Nutrinium deposit class
class NutriniumDeposit:
    def __init__(self, x, y, size):
        self.x = x
        self.y = y
        self.size = size
        self.radius = 10 * size
        self.amount = 10 * size
        self.color = GREEN
    
    def draw(self, screen):
        # Draw deposit
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), self.radius)
        
        # Draw amount indicator
        fill_ratio = self.amount / (10 * self.size)
        inner_radius = int(self.radius * fill_ratio)
        pygame.draw.circle(screen, (0, 255, 128), (int(self.x), int(self.y)), inner_radius)

# Pirate class
class Pirate:
    def __init__(self, x, y, speed, health):
        self.x = x
        self.y = y
        self.radius = 15
        self.speed = speed
        self.health = health
        self.max_health = health
        self.nutrinium = random.randint(5, 20)
        self.attack_cooldown = 0
        self.attack_rate = 1.5  # seconds
    
    def update(self, player):
        # Move towards player
        angle = math.atan2(player.y - self.y, player.x - self.x)
        self.x += math.cos(angle) * self.speed
        self.y += math.sin(angle) * self.speed
        
        # Update attack cooldown
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1/FPS
    
    def draw(self, screen):
        # Draw pirate body
        pygame.draw.circle(screen, RED, (int(self.x), int(self.y)), self.radius)
        
        # Draw pirate "skull and crossbones" (simplified)
        pygame.draw.circle(screen, WHITE, (int(self.x), int(self.y)), self.radius - 5)
        pygame.draw.circle(screen, BLACK, (int(self.x - 4), int(self.y - 2)), 2)
        pygame.draw.circle(screen, BLACK, (int(self.x + 4), int(self.y - 2)), 2)
        pygame.draw.rect(screen, BLACK, (int(self.x - 3), int(self.y + 2), 6, 2))
        
        # Draw health bar
        health_width = 30
        health_height = 5
        health_x = self.x - health_width // 2
        health_y = self.y - self.radius - 10
        
        # Background
        pygame.draw.rect(screen, RED, (health_x, health_y, health_width, health_height))
        
        # Foreground (current health)
        current_health_width = (self.health / self.max_health) * health_width
        pygame.draw.rect(screen, GREEN, (health_x, health_y, current_health_width, health_height))
        
        # Draw nutrinium indicator
        pygame.draw.circle(screen, GREEN, (int(self.x), int(self.y + self.radius + 5)), 3)
        nutrinium_text = str(self.nutrinium)
        nutrinium_surface = pygame.font.Font(None, 20).render(nutrinium_text, True, GREEN)
        screen.blit(nutrinium_surface, (self.x + 5, self.y + self.radius))
    
    def take_damage(self):
        self.health -= 1
    
    def collides_with(self, other):
        distance = math.sqrt((self.x - other.x) ** 2 + (self.y - other.y) ** 2)
        return distance < (self.radius + other.radius)

# Projectile class
class Projectile:
    def __init__(self, x, y, angle):
        self.x = x
        self.y = y
        self.radius = 3
        self.speed = 10
        self.angle = angle
        self.color = YELLOW
    
    def update(self):
        self.x += math.cos(self.angle) * self.speed
        self.y += math.sin(self.angle) * self.speed
    
    def draw(self, screen):
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), self.radius)
    
    def collides_with(self, other):
        distance = math.sqrt((self.x - other.x) ** 2 + (self.y - other.y) ** 2)
        return distance < (self.radius + other.radius)

# Explosion class
class Explosion:
    def __init__(self, x, y, large=False):
        self.x = x
        self.y = y
        self.frame = 0
        self.max_frames = 10
        self.radius = 5
        self.max_radius = 30 if large else 15
    
    def update(self):
        self.frame += 1
    
    def draw(self, screen):
        radius = int((self.frame / self.max_frames) * self.max_radius)
        alpha = 255 - int((self.frame / self.max_frames) * 255)
        
        # Create a surface with per-pixel alpha
        surface = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
        
        # Draw the explosion with fading alpha
        pygame.draw.circle(surface, (255, 165, 0, alpha), (radius, radius), radius)
        
        # Blit the surface onto the screen
        screen.blit(surface, (int(self.x - radius), int(self.y - radius)))

# Main game loop
def main():
    # Set SDL environment variables to handle headless environments better
    import os
    os.environ['SDL_VIDEODRIVER'] = 'dummy'
    
    try:
        game = GameState()
        
        # Display instructions
        show_instructions(game.screen)
        
        while game.running:
            # Handle events
            for event in pygame.event.get():
                game.handle_event(event)
            
            # Update game state
            if not game.game_over:
                game.update()
            
            # Render game
            game.render()
            
            # Cap the frame rate
            game.clock.tick(FPS)
    except Exception as e:
        print(f"Game error: {e}")
    finally:
        pygame.quit()
        sys.exit()

def show_instructions(screen):
    # Fill background
    screen.fill(BLACK)
    
    # Title
    title_font = pygame.font.Font(None, 72)
    title_text = "SirLootsalot"
    title_surface = title_font.render(title_text, True, BLUE)
    screen.blit(title_surface, (SCREEN_WIDTH//2 - title_surface.get_width()//2, 50))
    
    # Instructions
    font = pygame.font.Font(None, 36)
    instructions = [
        "You are SirLootsalot, a knight traveling through space!",
        "Mine nutrinium (green) and fight pirates (red) to collect credits.",
        "",
        "Controls:",
        "WASD / Arrow Keys: Move",
        "Mouse: Aim",
        "Space: Shoot",
        "S: Sell nutrinium for credits",
        "U: Upgrade mining speed",
        "",
        "Watch out! If you die, you'll lose all your nutrinium",
        "and respawning costs credits (cost doubles each time).",
        "",
        "You have 5 minutes to collect as many credits as possible!",
        "",
        "Press any key to start..."
    ]
    
    y = 150
    for line in instructions:
        text_surface = font.render(line, True, WHITE)
        screen.blit(text_surface, (SCREEN_WIDTH//2 - text_surface.get_width()//2, y))
        y += 30
    
    pygame.display.flip()
    
    # Wait for key press
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == KEYDOWN:
                waiting = False

if __name__ == "__main__":
    main()
