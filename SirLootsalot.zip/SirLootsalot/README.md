# SirLootsalot

A 2D space adventure game where you play as a knight traveling through space, mining nutrinium, and fighting pirates!

## Game Overview

In SirLootsalot, you play as a space knight who travels through the cosmos mining valuable nutrinium and battling space pirates. Your goal is to collect as many credits as possible within a 5-minute time limit.

### Key Features:

- **Space Knight Character**: Control SirLootsalot, a knight in space with a trusty lance
- **Resource Mining**: Mine nutrinium deposits scattered throughout space
- **Pirate Combat**: Battle space pirates and steal their nutrinium
- **Economy System**: Sell nutrinium for credits with a dynamic pricing system that follows a random walk
- **Upgrade System**: Improve your mining speed to collect resources faster
- **10 Unique Levels**: Progress through increasingly difficult levels with more pirates and resources
- **Permadeath Economy**: Dying makes you lose all your nutrinium and costs credits to respawn (cost doubles each time)
- **Time Challenge**: Earn as many credits as possible within a 5-minute time limit

## Controls

- **WASD / Arrow Keys**: Move SirLootsalot
- **Mouse**: Aim
- **Space**: Shoot projectiles
- **S**: Sell all your nutrinium for credits
- **U**: Upgrade mining speed (costs credits)
- **ESC**: Quit game
- **R**: Restart (after game over)
- **Q**: Quit (after game over)

## Game Mechanics

### Nutrinium Mining
- Approach green nutrinium deposits to mine them
- Mining speed depends on your mining level
- Upgrade mining level to extract nutrinium faster

### Combat
- Pirates (red) will chase you
- Shoot projectiles to damage pirates
- Pirates drop their nutrinium when defeated
- Colliding with pirates damages your health

### Economy
- Nutrinium value fluctuates over time (random walk with upward trend)
- Strategic selling when prices are high maximizes profits
- Credits are used for respawning and upgrades

### Death and Respawning
- Dying makes you lose all your nutrinium
- Respawning costs credits (cost doubles each time)
- If you can't afford to respawn, it's game over

## Installation and Running

### Requirements
- Python 3.x
- Pygame library

### Installation
1. Ensure Python is installed on your system
2. Install Pygame: `pip install pygame`
3. Download the game files

### Running the Game
```
python main.py
```

## Development Notes

This game was created using Python and Pygame. The code structure includes:

- **GameState**: Main game controller handling updates, rendering, and game logic
- **Player**: Controls the knight character and player interactions
- **NutriniumDeposit**: Represents minable resources in the game
- **Pirate**: Enemy characters that chase the player
- **Projectile**: Weapons fired by the player
- **Explosion**: Visual effects for combat

## Tips for Success

- Upgrade your mining speed early to collect resources faster
- Watch the nutrinium value and sell when prices are high
- Avoid pirates until you're ready to fight them
- Focus on mining in early levels when there are fewer pirates
- Don't die! Each death makes the next one more costly
