// Game configuration constants
const CONFIG = {
    // Game settings
    GAME_DURATION: 300, // 5 minutes in seconds
    
    // World settings
    WORLD_SIZE: 1000,
    GROUND_SIZE: 2000,
    
    // Player settings
    PLAYER_SPEED: 10,
    PLAYER_HEALTH: 5,
    PLAYER_START_CREDITS: 100,
    PLAYER_RESPAWN_COST: 50,
    PLAYER_MINING_LEVEL: 1,
    PLAYER_MINING_UPGRADE_COST: 100,
    
    // Camera settings
    CAMERA_HEIGHT: 15,
    CAMERA_DISTANCE: 30,
    CAMERA_FOV: 75,
    
    // Nutrinium settings
    NUTRINIUM_BASE_VALUE: 10.0,
    NUTRINIUM_SIZE_MULTIPLIER: 3,
    
    // Pirate settings
    PIRATE_SPAWN_INTERVAL: 5, // seconds
    PIRATE_SPEED_MULTIPLIER: 0.2,
    
    // Projectile settings
    PROJECTILE_SPEED: 20,
    PROJECTILE_LIFETIME: 3, // seconds
    
    // Colors
    COLORS: {
        PLAYER: 0x0000ff,
        NUTRINIUM: 0x00ff00,
        PIRATE: 0xff0000,
        PROJECTILE: 0xffff00,
        GROUND: 0x222222,
        SKYBOX: 0x000011
    }
};
