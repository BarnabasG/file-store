// Utility functions for the game

// Calculate distance between two 3D points
function distance(point1, point2) {
    return Math.sqrt(
        Math.pow(point2.x - point1.x, 2) +
        Math.pow(point2.y - point1.y, 2) +
        Math.pow(point2.z - point1.z, 2)
    );
}

// Random position within world bounds
function randomPosition(minDistance = 0, maxDistance = CONFIG.WORLD_SIZE / 2) {
    const angle = Math.random() * Math.PI * 2;
    const distance = minDistance + Math.random() * (maxDistance - minDistance);
    
    return {
        x: Math.cos(angle) * distance,
        z: Math.sin(angle) * distance,
        y: 0 // On the ground
    };
}

// Format time as MM:SS
function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// Create a simple colored sphere
function createSphere(radius, color, segments = 16) {
    const geometry = new THREE.SphereGeometry(radius, segments, segments);
    const material = new THREE.MeshLambertMaterial({ color: color });
    return new THREE.Mesh(geometry, material);
}

// Create a simple colored box
function createBox(width, height, depth, color) {
    const geometry = new THREE.BoxGeometry(width, height, depth);
    const material = new THREE.MeshLambertMaterial({ color: color });
    return new THREE.Mesh(geometry, material);
}

// Check if object is within world bounds
function isInBounds(position, buffer = 0) {
    const halfSize = CONFIG.WORLD_SIZE / 2 - buffer;
    return (
        position.x >= -halfSize &&
        position.x <= halfSize &&
        position.z >= -halfSize &&
        position.z <= halfSize
    );
}

// Clamp position to world bounds
function clampToBounds(position, buffer = 0) {
    const halfSize = CONFIG.WORLD_SIZE / 2 - buffer;
    position.x = Math.max(-halfSize, Math.min(halfSize, position.x));
    position.z = Math.max(-halfSize, Math.min(halfSize, position.z));
    return position;
}

// Update HTML element text
function updateHudElement(id, text) {
    const element = document.getElementById(id);
    if (element) {
        element.textContent = text;
    }
}

// Show/hide an element
function toggleElement(id, show) {
    const element = document.getElementById(id);
    if (element) {
        if (show) {
            element.classList.remove('hidden');
        } else {
            element.classList.add('hidden');
        }
    }
}

// Input Manager class for handling user input
class InputManager {
    constructor(game) {
        this.game = game;
        this.keys = {
            w: false,
            a: false,
            s: false,
            d: false,
            z: false,
            x: false,
            c: false,
            v: false
        };
        this.mouse = {
            x: 0,
            y: 0,
            isDown: false
        };
        this.camera = game.camera;
        
        // Set up event listeners
        this.setupEventListeners();
    }
    
    setupEventListeners() {
        // Keyboard events
        document.addEventListener('keydown', this.handleKeyDown.bind(this));
        document.addEventListener('keyup', this.handleKeyUp.bind(this));
        
        // Mouse events
        document.addEventListener('mousemove', this.handleMouseMove.bind(this));
        document.addEventListener('mousedown', this.handleMouseDown.bind(this));
        document.addEventListener('mouseup', this.handleMouseUp.bind(this));
        
        // Prevent context menu on right click
        document.addEventListener('contextmenu', (e) => e.preventDefault());
    }
    
    handleKeyDown(event) {
        // Movement keys
        if (event.key.toLowerCase() === 'w') this.keys.w = true;
        if (event.key.toLowerCase() === 'a') this.keys.a = true;
        if (event.key.toLowerCase() === 's') this.keys.s = true;
        if (event.key.toLowerCase() === 'd') this.keys.d = true;
        
        // Action keys (one-time press)
        if (event.key.toLowerCase() === 'z') this.handleActionKey('z');
        if (event.key.toLowerCase() === 'x') this.handleActionKey('x');
        if (event.key.toLowerCase() === 'c') this.handleActionKey('c');
        if (event.key.toLowerCase() === 'v') this.handleActionKey('v');
        
        // Escape key for pause
        if (event.key === 'Escape') {
            this.game.paused = !this.game.paused;
        }
    }
    
    handleKeyUp(event) {
        if (event.key.toLowerCase() === 'w') this.keys.w = false;
        if (event.key.toLowerCase() === 'a') this.keys.a = false;
        if (event.key.toLowerCase() === 's') this.keys.s = false;
        if (event.key.toLowerCase() === 'd') this.keys.d = false;
    }
    
    handleMouseMove(event) {
        this.mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
        this.mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
    }
    
    handleMouseDown(event) {
        if (event.button === 0) { // Left mouse button
            this.mouse.isDown = true;
            this.game.fireProjectile();
        }
    }
    
    handleMouseUp(event) {
        if (event.button === 0) { // Left mouse button
            this.mouse.isDown = false;
        }
    }
    
    handleActionKey(key) {
        switch (key) {
            case 'z':
                // Sell nutrinium
                this.game.sellNutrinium();
                break;
            case 'x':
                // Upgrade mining
                this.game.upgradeMining();
                break;
            case 'c':
                // Reserved for future use
                console.log('C key pressed - no action assigned');
                break;
            case 'v':
                // Reserved for future use
                console.log('V key pressed - no action assigned');
                break;
        }
    }
}
