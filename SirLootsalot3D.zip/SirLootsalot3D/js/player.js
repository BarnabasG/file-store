// Player class for SirLootsalot
class Player {
    constructor(scene) {
        this.scene = scene;
        
        // Player stats
        this.health = CONFIG.PLAYER_HEALTH;
        this.maxHealth = CONFIG.PLAYER_HEALTH;
        this.nutrinium = 0;
        this.credits = CONFIG.PLAYER_START_CREDITS;
        this.respawnCost = CONFIG.PLAYER_RESPAWN_COST;
        this.miningLevel = CONFIG.PLAYER_MINING_LEVEL;
        this.miningUpgradeCost = CONFIG.PLAYER_MINING_UPGRADE_COST;
        
        // Movement
        this.speed = CONFIG.PLAYER_SPEED;
        this.moveDirection = new THREE.Vector3();
        this.velocity = new THREE.Vector3();
        
        // Create player mesh (knight in space)
        this.createPlayerMesh();
        
        // Add to scene
        this.scene.add(this.mesh);
    }
    
    createPlayerMesh() {
        // Create player body (blue sphere for now, can be replaced with a knight model later)
        this.mesh = createSphere(2, CONFIG.COLORS.PLAYER);
        this.mesh.position.set(0, 2, 0); // Start at center of world, slightly above ground
        
        // Add a "sword" to represent the knight's weapon
        const sword = createBox(0.5, 0.5, 4, 0xCCCCCC);
        sword.position.set(0, 0, 2); // Extend forward
        this.mesh.add(sword);
        
        // Add a simple helmet to represent the knight
        const helmet = createSphere(1, 0x888888, 8);
        helmet.position.set(0, 0.8, 0); // Slightly above the center
        helmet.scale.set(1, 1.2, 1); // Elongate vertically
        this.mesh.add(helmet);
        
        // Add a visor
        const visor = createBox(1.5, 0.3, 0.1, 0x444444);
        visor.position.set(0, 0.8, 1); // Front of helmet
        this.mesh.add(visor);
        
        // Create collision properties
        this.radius = 2;
        this.mesh.userData.owner = this;
    }
    
    update(deltaTime, inputManager) {
        // Handle movement based on input
        this.moveDirection.set(0, 0, 0);
        
        // Forward/backward movement (relative to camera)
        if (inputManager.keys.w) {
            this.moveDirection.z = -1;
        } else if (inputManager.keys.s) {
            this.moveDirection.z = 1;
        }
        
        // Left/right movement (relative to camera)
        if (inputManager.keys.a) {
            this.moveDirection.x = -1;
        } else if (inputManager.keys.d) {
            this.moveDirection.x = 1;
        }
        
        // Normalize movement vector
        if (this.moveDirection.length() > 0) {
            this.moveDirection.normalize();
        }
        
        // Apply camera rotation to movement direction
        const cameraDirection = new THREE.Vector3();
        inputManager.camera.getWorldDirection(cameraDirection);
        cameraDirection.y = 0; // Keep movement on xz plane
        cameraDirection.normalize();
        
        // Calculate forward and right vectors
        const forward = cameraDirection.clone();
        const right = new THREE.Vector3();
        right.crossVectors(new THREE.Vector3(0, 1, 0), forward).normalize();
        
        // Apply movement in camera-relative directions
        const moveX = this.moveDirection.x * right.x + this.moveDirection.z * forward.x;
        const moveZ = this.moveDirection.x * right.z + this.moveDirection.z * forward.z;
        
        // Update velocity with smoothing
        const smoothing = 0.9;
        this.velocity.x = this.velocity.x * smoothing + moveX * this.speed * (1 - smoothing);
        this.velocity.z = this.velocity.z * smoothing + moveZ * this.speed * (1 - smoothing);
        
        // Apply velocity
        this.mesh.position.x += this.velocity.x * deltaTime;
        this.mesh.position.z += this.velocity.z * deltaTime;
        
        // Keep player within world bounds
        clampToBounds(this.mesh.position, this.radius);
        
        // Rotate player to face movement direction
        if (this.velocity.length() > 0.1) {
            const targetRotation = Math.atan2(this.velocity.x, this.velocity.z);
            
            // Smooth rotation
            let currentRotation = this.mesh.rotation.y;
            const rotationDiff = targetRotation - currentRotation;
            
            // Handle wrapping around 2π
            let adjustedRotationDiff = rotationDiff;
            if (rotationDiff > Math.PI) adjustedRotationDiff -= Math.PI * 2;
            if (rotationDiff < -Math.PI) adjustedRotationDiff += Math.PI * 2;
            
            // Apply smooth rotation
            this.mesh.rotation.y += adjustedRotationDiff * 5 * deltaTime;
        }
    }
    
    takeDamage() {
        this.health -= 1;
        return this.health <= 0;
    }
    
    die() {
        this.health = 0;
        this.nutrinium = 0;
        
        // Reset position
        this.mesh.position.set(0, 2, 0);
    }
    
    respawn() {
        if (this.credits >= this.respawnCost) {
            this.credits -= this.respawnCost;
            this.respawnCost *= 2;
            this.health = this.maxHealth;
            return true;
        }
        return false;
    }
    
    sellNutrinium(value) {
        if (this.nutrinium > 0) {
            const creditsEarned = this.nutrinium * value;
            this.credits += creditsEarned;
            this.nutrinium = 0;
            return creditsEarned;
        }
        return 0;
    }
    
    upgradeMining() {
        if (this.credits >= this.miningUpgradeCost) {
            this.credits -= this.miningUpgradeCost;
            this.miningLevel += 1;
            this.miningUpgradeCost *= 2;
            return true;
        }
        return false;
    }
    
    collidesWith(object) {
        const distance = this.mesh.position.distanceTo(object.mesh.position);
        return distance < (this.radius + object.radius);
    }
    
    getPosition() {
        return this.mesh.position.clone();
    }
    
    getRotation() {
        return this.mesh.rotation.y;
    }
    
    getForwardVector() {
        const forward = new THREE.Vector3(0, 0, -1);
        forward.applyQuaternion(this.mesh.quaternion);
        return forward;
    }
}
