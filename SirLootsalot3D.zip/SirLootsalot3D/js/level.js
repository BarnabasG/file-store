// Level class for managing game levels
class Level {
    constructor(scene, levelNumber) {
        this.scene = scene;
        this.levelNumber = levelNumber;
        this.nutriniumDeposits = [];
        this.pirates = [];
        this.spawnTimer = 0;
        
        // Set up level difficulty
        this.setupDifficulty();
        
        // Create level environment
        this.createEnvironment();
    }
    
    setupDifficulty() {
        // Base number of deposits and pirates scales with level
        this.initialDepositCount = 5 + this.levelNumber;
        this.maxPirateCount = Math.max(1, Math.floor(this.levelNumber * 1.5));
        
        // Spawn interval decreases with level (faster spawning)
        this.pirateSpawnInterval = Math.max(2, CONFIG.PIRATE_SPAWN_INTERVAL - (this.levelNumber * 0.3));
    }
    
    createEnvironment() {
        // Create ground plane
        const groundGeometry = new THREE.PlaneGeometry(CONFIG.GROUND_SIZE, CONFIG.GROUND_SIZE);
        const groundMaterial = new THREE.MeshLambertMaterial({ 
            color: CONFIG.COLORS.GROUND,
            side: THREE.DoubleSide
        });
        this.ground = new THREE.Mesh(groundGeometry, groundMaterial);
        this.ground.rotation.x = Math.PI / 2;
        this.ground.position.y = 0;
        this.scene.add(this.ground);
        
        // Add grid lines to ground
        const gridHelper = new THREE.GridHelper(CONFIG.GROUND_SIZE, 20, 0x444444, 0x333333);
        gridHelper.position.y = 0.1;
        this.scene.add(gridHelper);
        
        // Add boundary markers
        const halfSize = CONFIG.WORLD_SIZE / 2;
        const boundaryHeight = 10;
        
        // Create boundary pillars at corners
        const createBoundaryPillar = (x, z) => {
            const pillar = createBox(5, boundaryHeight, 5, 0x444444);
            pillar.position.set(x, boundaryHeight / 2, z);
            this.scene.add(pillar);
            
            // Add light on top
            const light = new THREE.PointLight(0xff0000, 1, 20);
            light.position.set(0, boundaryHeight / 2 + 2, 0);
            pillar.add(light);
        };
        
        // Create pillars at corners
        createBoundaryPillar(halfSize, halfSize);
        createBoundaryPillar(-halfSize, halfSize);
        createBoundaryPillar(halfSize, -halfSize);
        createBoundaryPillar(-halfSize, -halfSize);
        
        // Add some space debris/asteroids for visual interest
        for (let i = 0; i < 20; i++) {
            const size = 5 + Math.random() * 15;
            const asteroid = createSphere(size, 0x666666, 8);
            
            // Position randomly but outside the playable area
            const distance = CONFIG.WORLD_SIZE / 2 + 50 + Math.random() * 200;
            const angle = Math.random() * Math.PI * 2;
            asteroid.position.set(
                Math.cos(angle) * distance,
                -20 + Math.random() * 100, // Vary height
                Math.sin(angle) * distance
            );
            
            // Random rotation
            asteroid.rotation.set(
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2
            );
            
            this.scene.add(asteroid);
        }
        
        // Add stars (distant points)
        const starsGeometry = new THREE.BufferGeometry();
        const starsMaterial = new THREE.PointsMaterial({
            color: 0xffffff,
            size: 1
        });
        
        const starsVertices = [];
        for (let i = 0; i < 1000; i++) {
            const x = (Math.random() - 0.5) * 2000;
            const y = (Math.random() - 0.5) * 2000;
            const z = (Math.random() - 0.5) * 2000;
            starsVertices.push(x, y, z);
        }
        
        starsGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starsVertices, 3));
        const stars = new THREE.Points(starsGeometry, starsMaterial);
        this.scene.add(stars);
    }
    
    populate() {
        // Clear existing objects
        this.clearLevel();
        
        // Create initial nutrinium deposits
        for (let i = 0; i < this.initialDepositCount; i++) {
            this.spawnNutriniumDeposit();
        }
        
        // Spawn initial pirates
        for (let i = 0; i < Math.min(2, this.maxPirateCount); i++) {
            this.spawnPirate();
        }
    }
    
    clearLevel() {
        // Remove all nutrinium deposits
        for (const deposit of this.nutriniumDeposits) {
            deposit.remove();
        }
        this.nutriniumDeposits = [];
        
        // Remove all pirates
        for (const pirate of this.pirates) {
            pirate.remove();
        }
        this.pirates = [];
    }
    
    spawnNutriniumDeposit() {
        // Random position within world bounds
        const pos = randomPosition(50, CONFIG.WORLD_SIZE / 2 - 20);
        
        // Random size (1-3)
        const size = Math.floor(1 + Math.random() * 3);
        
        // Create deposit
        const deposit = new NutriniumDeposit(this.scene, pos, size);
        this.nutriniumDeposits.push(deposit);
        
        return deposit;
    }
    
    spawnPirate() {
        // Don't spawn if at max capacity
        if (this.pirates.length >= this.maxPirateCount) {
            return null;
        }
        
        // Random position at edge of world
        const angle = Math.random() * Math.PI * 2;
        const distance = CONFIG.WORLD_SIZE / 2 - 10;
        const pos = {
            x: Math.cos(angle) * distance,
            y: 0,
            z: Math.sin(angle) * distance
        };
        
        // Create pirate with level-appropriate difficulty
        const pirate = new Pirate(this.scene, pos, this.levelNumber);
        this.pirates.push(pirate);
        
        return pirate;
    }
    
    update(deltaTime, player) {
        // Update spawn timer for continuous enemy spawning
        this.spawnTimer += deltaTime;
        
        // Spawn new pirates at interval
        if (this.spawnTimer >= this.pirateSpawnInterval) {
            this.spawnPirate();
            this.spawnTimer = 0;
        }
        
        // Update all nutrinium deposits
        for (let i = this.nutriniumDeposits.length - 1; i >= 0; i--) {
            const deposit = this.nutriniumDeposits[i];
            
            // Check if player is mining this deposit
            if (player.collidesWith(deposit)) {
                const miningRate = 0.1 * player.miningLevel * deltaTime;
                const amountMined = deposit.mine(miningRate);
                player.nutrinium += amountMined;
                
                // Remove if depleted
                if (deposit.isDepleted()) {
                    deposit.remove();
                    this.nutriniumDeposits.splice(i, 1);
                    
                    // Spawn a new deposit elsewhere if below initial count
                    if (this.nutriniumDeposits.length < this.initialDepositCount / 2) {
                        this.spawnNutriniumDeposit();
                    }
                }
            }
        }
        
        // Update all pirates
        for (let i = this.pirates.length - 1; i >= 0; i--) {
            const pirate = this.pirates[i];
            pirate.update(deltaTime, player);
            
            // Check for collision with player
            if (pirate.collidesWith(player)) {
                const isDead = player.takeDamage();
                new Explosion(this.scene, player.getPosition());
                
                if (isDead) {
                    player.die();
                }
            }
        }
        
        // Check if level is complete (no more nutrinium and no more pirates)
        return this.nutriniumDeposits.length === 0 && this.pirates.length === 0;
    }
    
    handleProjectileCollisions(projectiles) {
        let hitCount = 0;
        
        // Check projectile collisions with pirates
        for (let i = projectiles.length - 1; i >= 0; i--) {
            const projectile = projectiles[i];
            
            for (let j = this.pirates.length - 1; j >= 0; j--) {
                const pirate = this.pirates[j];
                
                if (projectile.collidesWith(pirate)) {
                    // Pirate hit by projectile
                    const isDead = pirate.takeDamage();
                    new Explosion(this.scene, projectile.getPosition());
                    
                    // Remove projectile
                    projectile.remove();
                    projectiles.splice(i, 1);
                    
                    // If pirate is dead, remove it and transfer nutrinium
                    if (isDead) {
                        new Explosion(this.scene, pirate.getPosition(), true);
                        
                        // Transfer pirate's nutrinium to player
                        const player = this.scene.player;
                        if (player) {
                            player.nutrinium += pirate.nutrinium;
                        }
                        
                        // Remove pirate
                        pirate.remove();
                        this.pirates.splice(j, 1);
                    }
                    
                    hitCount++;
                    break;
                }
            }
        }
        
        return hitCount;
    }
    
    isComplete() {
        return this.nutriniumDeposits.length === 0 && this.pirates.length === 0;
    }
}
