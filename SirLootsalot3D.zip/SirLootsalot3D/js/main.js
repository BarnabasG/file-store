// Main.js - Entry point for the game

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', () => {
    // Create and initialize game
    const game = new Game();
    
    // Log initialization
    console.log('SirLootsalot 3D initialized');
    
    // Add keyboard controls info to console
    console.log('Controls:');
    console.log('- WASD: Move');
    console.log('- Mouse: Look around');
    console.log('- Left Click: Shoot');
    console.log('- Z: Sell nutrinium for credits');
    console.log('- X: Upgrade mining speed');
    console.log('- ESC: Pause game');
});
