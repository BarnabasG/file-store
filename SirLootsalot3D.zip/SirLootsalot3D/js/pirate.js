// Pirate enemy class
class Pirate {
    constructor(scene, position, level) {
        this.scene = scene;
        this.level = level;
        this.speed = 5 + (level * CONFIG.PIRATE_SPEED_MULTIPLIER);
        this.health = 2 + Math.floor(level / 2);
        this.maxHealth = this.health;
        this.nutrinium = Math.floor(5 + Math.random() * 15);
        this.radius = 2;
        this.target = null;
        
        // Create pirate mesh
        this.createMesh(position);
        
        // Add to scene
        this.scene.add(this.mesh);
    }
    
    createMesh(position) {
        // Create pirate body (red sphere)
        this.mesh = createSphere(this.radius, CONFIG.COLORS.PIRATE, 16);
        this.mesh.position.copy(position);
        this.mesh.position.y = this.radius; // Place on ground
        
        // Create pirate ship parts
        const shipBody = createBox(4, 1.5, 6, 0x880000);
        shipBody.position.y = 0.5;
        this.mesh.add(shipBody);
        
        // Add wings/fins
        const leftWing = createBox(3, 0.5, 2, 0x660000);
        leftWing.position.set(-3, 0, 0);
        shipBody.add(leftWing);
        
        const rightWing = createBox(3, 0.5, 2, 0x660000);
        rightWing.position.set(3, 0, 0);
        shipBody.add(rightWing);
        
        // Add skull and crossbones (simplified)
        const skull = createSphere(1, 0xffffff, 8);
        skull.position.set(0, 1.5, 0);
        shipBody.add(skull);
        
        // Add eyes
        const leftEye = createSphere(0.2, 0x000000, 8);
        leftEye.position.set(-0.4, 0.2, 0.7);
        skull.add(leftEye);
        
        const rightEye = createSphere(0.2, 0x000000, 8);
        rightEye.position.set(0.4, 0.2, 0.7);
        skull.add(rightEye);
        
        // Add crossbones
        const crossbone1 = createBox(2, 0.3, 0.3, 0xffffff);
        crossbone1.position.set(0, -0.5, 0);
        crossbone1.rotation.z = Math.PI / 4;
        skull.add(crossbone1);
        
        const crossbone2 = createBox(2, 0.3, 0.3, 0xffffff);
        crossbone2.position.set(0, -0.5, 0);
        crossbone2.rotation.z = -Math.PI / 4;
        skull.add(crossbone2);
        
        // Create health bar
        this.healthBar = new THREE.Group();
        this.healthBar.position.set(0, this.radius + 2, 0);
        
        // Health bar background
        const healthBg = createBox(3, 0.3, 0.1, 0xff0000);
        this.healthBar.add(healthBg);
        
        // Health bar foreground
        this.healthFg = createBox(3, 0.3, 0.2, 0x00ff00);
        this.healthFg.position.z = 0.1;
        this.healthBar.add(this.healthFg);
        
        this.mesh.add(this.healthBar);
        
        // Create nutrinium indicator
        const nutriniumIndicator = createSphere(0.5, CONFIG.COLORS.NUTRINIUM, 8);
        nutriniumIndicator.position.set(0, -this.radius - 1, 0);
        this.mesh.add(nutriniumIndicator);
        
        // Add nutrinium amount text (simulated with a small box for now)
        const nutriniumAmount = createBox(0.5 * this.nutrinium / 10, 0.5, 0.1, 0xffffff);
        nutriniumAmount.position.set(1, 0, 0);
        nutriniumIndicator.add(nutriniumAmount);
        
        // Create collision properties
        this.mesh.userData.owner = this;
    }
    
    update(deltaTime, player) {
        // Set player as target
        this.target = player;
        
        if (this.target) {
            // Calculate direction to player
            const targetPosition = this.target.getPosition();
            const direction = new THREE.Vector3();
            direction.subVectors(targetPosition, this.mesh.position);
            direction.y = 0; // Keep on xz plane
            
            // Normalize and apply speed
            if (direction.length() > 0.1) {
                direction.normalize();
                
                // Move towards player
                this.mesh.position.x += direction.x * this.speed * deltaTime;
                this.mesh.position.z += direction.z * this.speed * deltaTime;
                
                // Rotate to face player
                const targetRotation = Math.atan2(direction.x, direction.z);
                
                // Smooth rotation
                let currentRotation = this.mesh.rotation.y;
                const rotationDiff = targetRotation - currentRotation;
                
                // Handle wrapping around 2π
                let adjustedRotationDiff = rotationDiff;
                if (rotationDiff > Math.PI) adjustedRotationDiff -= Math.PI * 2;
                if (rotationDiff < -Math.PI) adjustedRotationDiff += Math.PI * 2;
                
                // Apply smooth rotation
                this.mesh.rotation.y += adjustedRotationDiff * 5 * deltaTime;
            }
        }
        
        // Update health bar
        this.healthFg.scale.x = this.health / this.maxHealth;
        this.healthFg.position.x = -1.5 * (1 - this.health / this.maxHealth);
        
        // Make health bar face camera
        if (this.scene.camera) {
            this.healthBar.lookAt(this.scene.camera.position);
        }
    }
    
    takeDamage() {
        this.health -= 1;
        return this.health <= 0;
    }
    
    isDead() {
        return this.health <= 0;
    }
    
    remove() {
        this.scene.remove(this.mesh);
    }
    
    getPosition() {
        return this.mesh.position.clone();
    }
    
    collidesWith(object) {
        const distance = this.mesh.position.distanceTo(object.mesh.position);
        return distance < (this.radius + object.radius);
    }
}
