// Nutrinium deposit class
class NutriniumDeposit {
    constructor(scene, position, size) {
        this.scene = scene;
        this.size = size;
        this.radius = 2 * size * CONFIG.NUTRINIUM_SIZE_MULTIPLIER;
        this.amount = 10 * size;
        this.maxAmount = this.amount;
        
        // Create nutrinium mesh
        this.createMesh(position);
        
        // Add to scene
        this.scene.add(this.mesh);
    }
    
    createMesh(position) {
        // Create outer sphere (deposit)
        this.mesh = createSphere(this.radius, CONFIG.COLORS.NUTRINIUM, 16);
        this.mesh.position.copy(position);
        this.mesh.position.y = this.radius; // Place on ground
        
        // Create inner sphere (fill level indicator)
        this.innerMesh = createSphere(this.radius * 0.9, 0x00ff80, 16);
        this.innerMesh.scale.set(1, 1, 1); // Will be updated based on amount
        this.mesh.add(this.innerMesh);
        
        // Add some crystal-like geometry to make it look more interesting
        for (let i = 0; i < 5; i++) {
            const crystal = createBox(
                this.radius * 0.2, 
                this.radius * 0.8, 
                this.radius * 0.2, 
                0x00ff80
            );
            
            // Position crystals around the sphere
            const angle = (i / 5) * Math.PI * 2;
            const distance = this.radius * 0.7;
            crystal.position.set(
                Math.cos(angle) * distance,
                this.radius * 0.2,
                Math.sin(angle) * distance
            );
            
            // Rotate crystals to point outward
            crystal.lookAt(
                this.mesh.position.x + Math.cos(angle) * this.radius * 2,
                this.mesh.position.y + this.radius * 0.2,
                this.mesh.position.z + Math.sin(angle) * this.radius * 2
            );
            
            this.mesh.add(crystal);
        }
        
        // Create collision properties
        this.mesh.userData.owner = this;
    }
    
    update() {
        // Update inner sphere scale based on remaining amount
        const fillRatio = this.amount / this.maxAmount;
        this.innerMesh.scale.set(fillRatio, fillRatio, fillRatio);
    }
    
    mine(miningRate) {
        const amountMined = Math.min(miningRate, this.amount);
        this.amount -= amountMined;
        this.update();
        
        return amountMined;
    }
    
    isDepleted() {
        return this.amount <= 0;
    }
    
    remove() {
        this.scene.remove(this.mesh);
    }
    
    getPosition() {
        return this.mesh.position.clone();
    }
}
