// Game class - main game controller
class Game {
    constructor() {
        // Game state
        this.running = false;
        this.gameOver = false;
        this.paused = false;
        this.currentLevel = 1;
        this.startTime = 0;
        this.remainingTime = CONFIG.GAME_DURATION;
        this.lastFrameTime = 0;
        
        // Game objects
        this.player = null;
        this.level = null;
        this.projectiles = [];
        this.explosions = [];
        
        // Economy
        this.nutriniumValue = CONFIG.NUTRINIUM_BASE_VALUE;
        this.valueChangeTimer = 0;
        this.valueChangeFrequency = 2; // seconds
        
        // Setup Three.js scene
        this.setupScene();
        
        // Setup input manager
        this.inputManager = new InputManager(this);
        
        // Setup event listeners
        this.setupEventListeners();
        
        // Show instructions
        this.showInstructions();
    }
    
    setupScene() {
        // Create scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(CONFIG.COLORS.SKYBOX);
        
        // Create camera
        this.camera = new THREE.PerspectiveCamera(
            CONFIG.CAMERA_FOV,
            window.innerWidth / window.innerHeight,
            0.1,
            2000
        );
        this.scene.camera = this.camera; // Reference for other objects
        
        // Create renderer
        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.shadowMap.enabled = true;
        document.getElementById('game-container').appendChild(this.renderer.domElement);
        
        // Add lights
        this.addLights();
        
        // Handle window resize
        window.addEventListener('resize', () => {
            this.camera.aspect = window.innerWidth / window.innerHeight;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(window.innerWidth, window.innerHeight);
        });
    }
    
    addLights() {
        // Add ambient light
        const ambientLight = new THREE.AmbientLight(0x404040, 0.5);
        this.scene.add(ambientLight);
        
        // Add directional light (sun)
        const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
        directionalLight.position.set(100, 100, 100);
        directionalLight.castShadow = true;
        
        // Set up shadow properties
        directionalLight.shadow.mapSize.width = 2048;
        directionalLight.shadow.mapSize.height = 2048;
        directionalLight.shadow.camera.near = 0.5;
        directionalLight.shadow.camera.far = 500;
        directionalLight.shadow.camera.left = -100;
        directionalLight.shadow.camera.right = 100;
        directionalLight.shadow.camera.top = 100;
        directionalLight.shadow.camera.bottom = -100;
        
        this.scene.add(directionalLight);
        
        // Add hemisphere light (sky/ground)
        const hemisphereLight = new THREE.HemisphereLight(0x0044ff, 0x444422, 0.5);
        this.scene.add(hemisphereLight);
    }
    
    setupEventListeners() {
        // Add crosshair element
        const crosshair = document.createElement('div');
        crosshair.id = 'crosshair';
        document.getElementById('game-container').appendChild(crosshair);
        
        // Instructions click handler
        document.getElementById('instructions').addEventListener('click', () => {
            this.startGame();
        });
        
        // Game over key handlers
        document.addEventListener('keydown', (event) => {
            if (this.gameOver) {
                if (event.key === 'r' || event.key === 'R') {
                    this.resetGame();
                } else if (event.key === 'q' || event.key === 'Q') {
                    window.close();
                }
            }
        });
    }
    
    showInstructions() {
        toggleElement('instructions', true);
        toggleElement('game-over', false);
    }
    
    startGame() {
        // Hide instructions
        toggleElement('instructions', false);
        
        // Create player
        this.player = new Player(this.scene);
        this.scene.player = this.player; // Reference for other objects
        
        // Create first level
        this.setupLevel(1);
        
        // Set start time
        this.startTime = Date.now() / 1000;
        this.lastFrameTime = this.startTime;
        
        // Start game loop
        this.running = true;
        requestAnimationFrame(this.gameLoop.bind(this));
    }
    
    setupLevel(levelNumber) {
        // Clear existing level if any
        if (this.level) {
            this.level.clearLevel();
        }
        
        // Create new level
        this.level = new Level(this.scene, levelNumber);
        this.level.populate();
        
        // Update HUD
        updateHudElement('level', `Level: ${levelNumber}/10`);
    }
    
    resetGame() {
        // Hide game over screen
        toggleElement('game-over', false);
        
        // Reset game state
        this.gameOver = false;
        this.currentLevel = 1;
        this.startTime = Date.now() / 1000;
        this.lastFrameTime = this.startTime;
        this.remainingTime = CONFIG.GAME_DURATION;
        this.nutriniumValue = CONFIG.NUTRINIUM_BASE_VALUE;
        
        // Clear projectiles
        for (const projectile of this.projectiles) {
            projectile.remove();
        }
        this.projectiles = [];
        
        // Clear explosions
        for (const explosion of this.explosions) {
            explosion.remove();
        }
        this.explosions = [];
        
        // Reset player
        if (this.player) {
            this.scene.remove(this.player.mesh);
        }
        this.player = new Player(this.scene);
        this.scene.player = this.player;
        
        // Reset level
        this.setupLevel(1);
        
        // Restart game loop
        this.running = true;
        requestAnimationFrame(this.gameLoop.bind(this));
    }
    
    gameLoop(timestamp) {
        if (!this.running) return;
        
        // Calculate delta time
        const currentTime = timestamp / 1000; // Convert to seconds
        const deltaTime = Math.min(0.1, currentTime - this.lastFrameTime); // Cap at 0.1 seconds
        this.lastFrameTime = currentTime;
        
        // Update game timer
        const elapsedTime = currentTime - this.startTime;
        this.remainingTime = Math.max(0, CONFIG.GAME_DURATION - elapsedTime);
        
        // Check for game over
        if (this.remainingTime <= 0) {
            this.endGame();
        }
        
        if (!this.gameOver && !this.paused) {
            // Update nutrinium value
            this.updateNutriniumValue(deltaTime);
            
            // Update player
            this.player.update(deltaTime, this.inputManager);
            
            // Update camera position to follow player
            this.updateCamera();
            
            // Update level
            if (this.level) {
                const levelComplete = this.level.update(deltaTime, this.player);
                
                // Check if level is complete
                if (levelComplete) {
                    this.currentLevel++;
                    
                    if (this.currentLevel <= 10) {
                        this.setupLevel(this.currentLevel);
                    } else {
                        // Loop back to level 1 with increased difficulty
                        this.currentLevel = 1;
                        this.setupLevel(this.currentLevel);
                    }
                }
            }
            
            // Update projectiles
            for (let i = this.projectiles.length - 1; i >= 0; i--) {
                const projectile = this.projectiles[i];
                const shouldRemove = projectile.update(deltaTime);
                
                if (shouldRemove) {
                    projectile.remove();
                    this.projectiles.splice(i, 1);
                }
            }
            
            // Check projectile collisions
            if (this.level) {
                this.level.handleProjectileCollisions(this.projectiles);
            }
            
            // Update explosions
            for (let i = this.explosions.length - 1; i >= 0; i--) {
                const explosion = this.explosions[i];
                const isComplete = explosion.update(deltaTime);
                
                if (isComplete) {
                    this.explosions.splice(i, 1);
                }
            }
            
            // Update HUD
            this.updateHUD();
        }
        
        // Render scene
        this.renderer.render(this.scene, this.camera);
        
        // Continue game loop
        requestAnimationFrame(this.gameLoop.bind(this));
    }
    
    updateCamera() {
        if (!this.player) return;
        
        // Get player position
        const playerPos = this.player.getPosition();
        
        // Calculate camera position (third-person view)
        const cameraOffset = new THREE.Vector3(0, CONFIG.CAMERA_HEIGHT, CONFIG.CAMERA_DISTANCE);
        
        // Rotate offset based on player rotation
        const playerRotation = this.player.getRotation();
        const rotatedOffset = cameraOffset.clone();
        rotatedOffset.applyAxisAngle(new THREE.Vector3(0, 1, 0), playerRotation);
        
        // Set camera position
        this.camera.position.copy(playerPos).add(rotatedOffset);
        
        // Look at player
        this.camera.lookAt(playerPos);
    }
    
    updateNutriniumValue(deltaTime) {
        this.valueChangeTimer += deltaTime;
        
        if (this.valueChangeTimer >= this.valueChangeFrequency) {
            // Random walk with upward trend
            const change = Math.random() * 2.5 - 1.0; // Slight upward bias
            this.nutriniumValue = Math.max(5.0, this.nutriniumValue + change);
            
            // Occasional larger market movements
            if (Math.random() < 0.05) { // 5% chance
                this.nutriniumValue *= 0.8 + Math.random() * 0.5; // 0.8 to 1.3 multiplier
            }
            
            this.valueChangeTimer = 0;
        }
    }
    
    updateHUD() {
        // Update time
        updateHudElement('timer', `Time: ${formatTime(this.remainingTime)}`);
        
        // Update credits
        updateHudElement('credits', `Credits: ${Math.floor(this.player.credits)}`);
        
        // Update nutrinium
        updateHudElement('nutrinium', `Nutrinium: ${Math.floor(this.player.nutrinium)}`);
        
        // Update nutrinium value
        updateHudElement('nutrinium-value', `Value: ${this.nutriniumValue.toFixed(1)}`);
        
        // Update health
        updateHudElement('health', `Health: ${this.player.health}/${this.player.maxHealth}`);
        
        // Update respawn cost
        updateHudElement('respawn-cost', `Respawn: ${this.player.respawnCost}`);
    }
    
    fireProjectile() {
        if (!this.player || this.gameOver || this.paused) return;
        
        // Get player position and forward vector
        const playerPos = this.player.getPosition();
        const forwardVector = this.player.getForwardVector();
        
        // Create projectile
        const projectile = new Projectile(this.scene, playerPos, forwardVector);
        this.projectiles.push(projectile);
    }
    
    sellNutrinium() {
        if (!this.player || this.gameOver || this.paused) return;
        
        const creditsEarned = this.player.sellNutrinium(this.nutriniumValue);
        
        if (creditsEarned > 0) {
            console.log(`Sold nutrinium for ${creditsEarned.toFixed(1)} credits`);
        }
    }
    
    upgradeMining() {
        if (!this.player || this.gameOver || this.paused) return;
        
        const upgraded = this.player.upgradeMining();
        
        if (upgraded) {
            console.log(`Upgraded mining to level ${this.player.miningLevel}`);
        } else {
            console.log(`Not enough credits to upgrade mining`);
        }
    }
    
    endGame() {
        this.gameOver = true;
        this.running = false;
        
        // Update final score
        updateHudElement('final-score', `Final Credits: ${Math.floor(this.player.credits)}`);
        
        // Show game over screen
        toggleElement('game-over', true);
    }
    
    addExplosion(position, large = false) {
        const explosion = new Explosion(this.scene, position, large);
        this.explosions.push(explosion);
    }
}
