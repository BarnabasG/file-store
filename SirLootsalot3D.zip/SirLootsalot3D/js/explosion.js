// Explosion class
class Explosion {
    constructor(scene, position, large = false) {
        this.scene = scene;
        this.position = position.clone();
        this.frame = 0;
        this.maxFrames = 20;
        this.radius = large ? 6 : 3;
        this.particles = [];
        
        // Create explosion effect
        this.createExplosion(large);
    }
    
    createExplosion(large) {
        // Create explosion group
        this.mesh = new THREE.Group();
        this.mesh.position.copy(this.position);
        
        // Create particle count based on explosion size
        const particleCount = large ? 30 : 15;
        
        // Create particles
        for (let i = 0; i < particleCount; i++) {
            // Random direction
            const direction = new THREE.Vector3(
                Math.random() * 2 - 1,
                Math.random() * 2 - 1,
                Math.random() * 2 - 1
            ).normalize();
            
            // Random speed
            const speed = 2 + Math.random() * 8;
            
            // Random size
            const size = 0.3 + Math.random() * 0.7;
            
            // Create particle
            const particle = createSphere(size, 0xff6600, 8);
            
            // Add to group
            this.mesh.add(particle);
            
            // Store particle data
            this.particles.push({
                mesh: particle,
                direction: direction,
                speed: speed,
                initialSize: size
            });
        }
        
        // Add light flash
        this.light = new THREE.PointLight(0xff6600, 3, 10);
        this.mesh.add(this.light);
        
        // Add to scene
        this.scene.add(this.mesh);
    }
    
    update(deltaTime) {
        // Update frame counter
        this.frame++;
        
        // Calculate progress (0 to 1)
        const progress = this.frame / this.maxFrames;
        
        // Update particles
        for (const particle of this.particles) {
            // Move particle outward
            particle.mesh.position.x += particle.direction.x * particle.speed * deltaTime;
            particle.mesh.position.y += particle.direction.y * particle.speed * deltaTime;
            particle.mesh.position.z += particle.direction.z * particle.speed * deltaTime;
            
            // Shrink particle
            const scale = (1 - progress) * particle.initialSize;
            particle.mesh.scale.set(scale, scale, scale);
            
            // Fade particle
            if (particle.mesh.material.opacity !== undefined) {
                particle.mesh.material.opacity = 1 - progress;
            }
        }
        
        // Fade light
        this.light.intensity = 3 * (1 - progress);
        
        // Check if explosion is complete
        if (this.frame >= this.maxFrames) {
            this.remove();
            return true;
        }
        
        return false;
    }
    
    remove() {
        this.scene.remove(this.mesh);
    }
}
