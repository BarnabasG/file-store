// Projectile class
class Projectile {
    constructor(scene, position, direction) {
        this.scene = scene;
        this.direction = direction.normalize();
        this.speed = CONFIG.PROJECTILE_SPEED;
        this.radius = 0.5;
        this.lifetime = CONFIG.PROJECTILE_LIFETIME;
        this.timeAlive = 0;
        
        // Create projectile mesh
        this.createMesh(position);
        
        // Add to scene
        this.scene.add(this.mesh);
    }
    
    createMesh(position) {
        // Create projectile (yellow sphere)
        this.mesh = createSphere(this.radius, CONFIG.COLORS.PROJECTILE, 8);
        this.mesh.position.copy(position);
        this.mesh.position.y = 2; // Shoot from player's center
        
        // Add a trail effect
        const trail = new THREE.Group();
        
        // Create multiple trail segments
        for (let i = 0; i < 5; i++) {
            const segment = createSphere(this.radius * (1 - i * 0.15), CONFIG.COLORS.PROJECTILE, 8);
            segment.position.z = -i * 0.5; // Trail behind the projectile
            segment.material.transparent = true;
            segment.material.opacity = 1 - (i * 0.2);
            trail.add(segment);
        }
        
        this.mesh.add(trail);
        
        // Create collision properties
        this.mesh.userData.owner = this;
    }
    
    update(deltaTime) {
        // Move projectile
        this.mesh.position.x += this.direction.x * this.speed * deltaTime;
        this.mesh.position.y += this.direction.y * this.speed * deltaTime;
        this.mesh.position.z += this.direction.z * this.speed * deltaTime;
        
        // Update lifetime
        this.timeAlive += deltaTime;
        
        // Check if projectile should be removed
        return this.timeAlive >= this.lifetime || !isInBounds(this.mesh.position);
    }
    
    remove() {
        this.scene.remove(this.mesh);
    }
    
    getPosition() {
        return this.mesh.position.clone();
    }
    
    collidesWith(object) {
        const distance = this.mesh.position.distanceTo(object.mesh.position);
        return distance < (this.radius + object.radius);
    }
}
